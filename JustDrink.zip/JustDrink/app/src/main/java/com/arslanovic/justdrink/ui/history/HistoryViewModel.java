package com.arslanovic.justdrink.ui.history;

import androidx.lifecycle.ViewModel;

public class HistoryViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}